# TP2 - INF3210
###### 15/02/2020
##### Nicole Joyal - 1794431
##### Philippe Maisonneuve - 1959052
##### Soumis à : Doriane Olewicki

Nous n'avons pas réussi à faire le compte d'opérateurs. Nous avons tenté d'incrémenter le nombre d'opérateurs lorsque le nombre d'enfants d'un noeud était supéreur à un et dans les fonctions *visit* des opérateurs.

Afin de simplifier le code, nous aurions subdivisé les boucles de vérification de types en une fonction unique.